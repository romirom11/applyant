import{t,v as d}from"./entry.client-D-8RNsZm.js";import"./vendor-Ann2cuF6.js";export{t as ErrorBoundary,d as default};
//# sourceMappingURL=root-B9k9tVh1.js.map
